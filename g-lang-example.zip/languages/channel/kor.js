module.exports = {
    "name_label": "채널명",
    "name_input_placeholder": "채널명을 입력해주세요",
    "description_label": "채널 설명",
    "description_input_placeholder": "채널 설명을 입력해주세요"
}
