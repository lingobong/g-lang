module.exports = {
    "name_label": "Channel Name",
    "name_input_placeholder": "Please enter your channel name",
    "description_label": "Channel Description",
    "description_input_placeholder": "Please enter your channel description"
}
