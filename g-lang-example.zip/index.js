
const { lang, getLanguage, setLanguage, setLanguages, onChangeLanguage } = require('g-lang');

setLanguages({
    en: require('./languages/default'),
    kor: require('./languages/kor')
})

onChangeLanguage(function (nextLang, prevLang) {
    console.log('lang changed !!', `${nextLang} => ${prevLang}`)
})

setLanguage('kor')
console.log(getLanguage(), lang.channel.name_label)
console.log(getLanguage(), lang.video.title)

setLanguage('en')
console.log(getLanguage(), lang.channel.name_label)
console.log(getLanguage(), lang.video.title)