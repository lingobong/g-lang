module.exports = {
    "channel": require('./channel/default'),
    "video": require('./video/default'),
}