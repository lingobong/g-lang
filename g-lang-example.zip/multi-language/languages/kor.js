module.exports = {
    "channel": require('./channel/kor'),
    "video": require('./video/kor'),
}