
const { lang, getLanguage, setLanguage, setLanguages } = require('g-lang');

setLanguages({
    en: require('./languages/default'),
    kor: require('./languages/kor')
})

setLanguage('kor')
console.log(getLanguage(), lang.channel.name_label)
console.log(getLanguage(), lang.video.title)

setLanguage('en')
console.log(getLanguage(), lang.channel.name_label)
console.log(getLanguage(), lang.video.title)